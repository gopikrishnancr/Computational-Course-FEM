function out = load_new(x)
out  = 2;
