function out = load(x)
out  = 2;
